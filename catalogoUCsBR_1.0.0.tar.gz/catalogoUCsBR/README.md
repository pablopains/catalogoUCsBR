# catalogoUCsBR
The package is designed to convert species occurrence data from the Jabot Geral, Jabot RB, Reflora, SpeciesLink and GBIF data portals into a more understandable format for use in preparing species listings for the Plant Catalog of Units of Brazilian Conservation.
